package com.regPlatform.regPlatform.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.regPlatform.regPlatform.entity.PatientRecord;

public interface PatientRecordDao extends JpaRepository<PatientRecord, Integer>{

}
