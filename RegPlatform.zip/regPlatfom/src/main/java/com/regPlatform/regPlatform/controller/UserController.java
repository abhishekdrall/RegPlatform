package com.regPlatform.regPlatform.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.regPlatform.regPlatform.entity.Appointment;
import com.regPlatform.regPlatform.entity.DoctorRecord;
import com.regPlatform.regPlatform.entity.PatientRecord;
import com.regPlatform.regPlatform.service.Service;

@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired
	public Service services;
	
		
		//Get list of all stored Patient
		@GetMapping(path="patientrecorddetails",consumes="application/json")
		public List<PatientRecord> getPatientRecord(){
			return this.services.getPatientRecord();
		}
		
		// New Entry for Patient
		@PostMapping(path="addpatientrecord")
		public ResponseEntity<PatientRecord> addPatientRecord(@Valid @RequestBody PatientRecord patientRecord){
			PatientRecord savedPatientRecord=services.addPatiendRecord(patientRecord);
			return new ResponseEntity<PatientRecord>(savedPatientRecord, HttpStatus.CREATED);
		}
	
		// Update entry for Patient
		@PutMapping(path="updatepatientrecord")
		public PatientRecord updatePatientRecord(@RequestBody PatientRecord patientRecord) {
			return this.services.updatePatientRecord(patientRecord);
		}
		
		// Delete entry for Patient
		@DeleteMapping(path="deletepatientrecord/{pId}")
		public ResponseEntity<HttpStatus> deletePatientRecord(@PathVariable String pId){
			try {
				this.services.deletePatientRecord(Integer.parseInt(pId));
				return new ResponseEntity<>(HttpStatus.OK);
			}catch (Exception e) {
				return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
			}
		}
		
//-------------------------------------------//
		
		//Get list of all stored Doctor
				@GetMapping(path="doctorrecorddetails",consumes="application/json")
				public List<DoctorRecord> getDoctorRecord(){
					return this.services.getDoctorRecord();
				}
				
				// New Entry for Doctor
				@PostMapping(path="adddoctorrecord")
				public ResponseEntity<DoctorRecord> addDoctorRecord(@RequestBody DoctorRecord doctorRecord){
					DoctorRecord savedDoctorRecord=services.addDoctorRecord(doctorRecord);
					return new ResponseEntity<DoctorRecord>(savedDoctorRecord, HttpStatus.CREATED);
				}
			
				// Update entry for Doctor
				@PutMapping(path="updatedoctorrecord")
				public DoctorRecord updateDoctorRecord(@RequestBody DoctorRecord doctorRecord) {
					return this.services.updateDoctorRecord(doctorRecord);
				}
				
				// Delete entry for Doctor
				@DeleteMapping(path="deletedoctorrecord/{docId}")
				public ResponseEntity<HttpStatus> deleteDoctorRecord(@PathVariable String docId){
					try {
						this.services.deleteDoctorRecord(Integer.parseInt(docId));
						return new ResponseEntity<>(HttpStatus.OK);
					}catch (Exception e) {
						return new ResponseEntity<>(HttpStatus.INTERNAL_SERVER_ERROR);
					}
				}
				
//---------------------------------------------//
				
				
				
				@GetMapping(path="sorteddetails/{field}",consumes="application/json")
				public List<Appointment> getSortedRecord(@PathVariable String field){
					return this.services.getSortedRecord(field);
				}
				// New Patient appointment
				@PostMapping(path="setAppointment")
				public ResponseEntity<Appointment> setAppointment(@Valid @RequestBody Appointment appointments){
					Appointment setAppointment=services.setAppointment(appointments);
					return new ResponseEntity<Appointment>(setAppointment, HttpStatus.CREATED);
				}
			
//				@PostMapping(path="setAppointment")
//				public List<DoctorRecord> setAppointment(@PathVariable String field){
//					List<DoctorRecord> sortedRecord=services.getSortedRecord(field);
//					return sortedRecord;
//					DoctorRecord savedDoctorRecord=services.addDoctorRecord(doctorRecord);
//					return new ResponseEntity<DoctorRecord>(savedDoctorRecord, HttpStatus.CREATED);
//				}
			
}
