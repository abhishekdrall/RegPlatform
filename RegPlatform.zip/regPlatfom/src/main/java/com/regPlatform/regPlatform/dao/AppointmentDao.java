package com.regPlatform.regPlatform.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.regPlatform.regPlatform.entity.Appointment;

public interface AppointmentDao extends JpaRepository<Appointment, Integer>{
	

}