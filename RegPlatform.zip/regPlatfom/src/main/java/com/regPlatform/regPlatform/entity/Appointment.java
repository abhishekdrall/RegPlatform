package com.regPlatform.regPlatform.entity;

import java.sql.Date;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Appointment {

	

	@Id
	@GeneratedValue( strategy= GenerationType.IDENTITY )
	private Integer code;
	private String speciality;
	
	private Date dateToVisit;
	private String status;

	@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	private DoctorRecord doctorRecord;

	@ManyToOne(fetch = FetchType.LAZY,cascade = CascadeType.ALL)
	private PatientRecord patientRecord;

	public int getCode() {
		return code;
	}

	public void setCode(int code) {
		this.code = code;
	}

	public String getSpeciality() {
		return speciality;
	}

	public void setSpeciality(String speciality) {
		this.speciality = speciality;
	}

	public Date getDateToVisit() {
		return dateToVisit;
	}

	public void setDateToVisit(Date dateToVisit) {
		this.dateToVisit = dateToVisit;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public DoctorRecord getDoctorRecord() {
		return doctorRecord;
	}

	public void setDoctorRecord(DoctorRecord doctorRecord) {
		this.doctorRecord = doctorRecord;
	}

	public PatientRecord getPatientRecord() {
		return patientRecord;
	}

	public void setPatientRecord(PatientRecord patientRecord) {
		this.patientRecord = patientRecord;
	}

	public Appointment() {
		super();
	}

	@Override
	public String toString() {
		return "Appointment [code=" + code + ", speciality=" + speciality + ", dateToVisit=" + dateToVisit + ", status="
				+ status + ", doctorRecord=" + doctorRecord + ", patientRecord=" + patientRecord + "]";
	}
	

	
}
