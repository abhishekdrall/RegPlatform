package com.regPlatform.regPlatform;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RegPlatfomApplication {

	public static void main(String[] args) {
		SpringApplication.run(RegPlatfomApplication.class, args);
	}

}
